<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>Olá meus adms disponível no momento são\n @suleiman171 e @suleimansuporte</b>",
	'parse_mode' => 'html'
]);