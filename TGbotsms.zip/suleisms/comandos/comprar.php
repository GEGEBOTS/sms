<?php

$tlg->answerCallbackQuery ([
	'callback_query_id' => $tlg->Callback_ID (),
	'text' => 'Gerando link de pagamento...'
]);

$valor = number_format ($complemento, 2);
$hash = $tlg->UserID ().mt_rand(111111, 999999);

$mp = new MercadoPago (ACCESS_TOKEN_MERCADO_PAGO);
$pagamento = $mp->setPreferencia ([
	"items" => [
		[
			"picture_url" => "https://i.ibb.co/fn6MNYp/photo4972283634740472126-3.jpg",
			"title" => "Saldo Sms Bot",
            "description" => "Saldo enviado Para sua conta, voce acaba de fazer uma venda!!!",
            "quantity" => 1,
            "currency_id" => "BRL",
            "unit_price" => (float)$valor
		]
	],
	"external_reference" => $hash,
	"expires" => true,
	"expiration_date_to" => date ('c', strtotime('+1 day'))
]);

if (!isset ($pagamento ['external_reference'])){

	$tlg->editMessageText ([
		'chat_id' => $tlg->ChatID (),
		'text' => "<em>⚠️ Erro ao gerar o seu link de pagamento, por favor tente novamente!\n ou tente o pagamento manual digitando /pixmanual</em>",
		'parse_mode' => 'html',
		'message_id' => $tlg->MessageID (),
		'reply_markup' => $tlg->buildInlineKeyboard ([
			[
				$tlg->buildInlineKeyBoardButton ("Tentar Novamente", null, "/comprar {$valor}")
			]
		])
	]);

}else {

	$tlg->editMessageText ([
		'chat_id' => $tlg->ChatID (),
		'text' => "💡 Pague por <em>pix, boleto, saldo ou cartão.</em>\n\n<u>Após o pagamento o saldo será adicionado na sua conta automaticamente.</u>\n\n<b>PAGAMENTOS POR BOLETO PODE DEMORAR ATE 72 HORAS PARA SE ADD O SALDO NA SUA CONTA!!!!</b>\n Apois pago o saldo e adicionado automaticamente",
		'parse_mode' => 'html',
		'message_id' => $tlg->MessageID (),
		'reply_markup' => $tlg->buildInlineKeyboard ([
			[
				$tlg->buildInlineKeyBoardButton ("Pagar R\${$valor}", $pagamento ['init_point'])
			]
		])
	]);

}