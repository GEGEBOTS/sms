<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>📜 · @suleimansmsbot \n\n ▫️ · SUPORTE: @suleiman171</b>",
	'parse_mode' => 'html'
]);